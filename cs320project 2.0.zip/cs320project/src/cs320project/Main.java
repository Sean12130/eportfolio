package cs320project;

import java.util.Date;
import java.util.Scanner;

/*
 * Main.java
 * -------------------------
 * This class acts as the user interface layer for the application.
 * It connects the AppointmentService, ContactService, and TaskService
 * into one integrated console-based system.
 *
 * Design Purpose:
 * The goal of this program is to demonstrate how service classes manage
 * business logic while the Main class handles user interaction.
 *
 * This structure supports:
 * - Separation of concerns
 * - Maintainability
 * - Testability with JUnit
 * - Object-oriented design principles
 */

public class Main {

    // Scanner is used to collect user input from the console
    private static Scanner scanner = new Scanner(System.in);

    // Create service objects that manage system data
    private static AppointmentService appointmentService =
            new AppointmentService();

    private static ContactService contactService =
            new ContactService();

    private static TaskService taskService =
            new TaskService();

    /*
     * Program Entry Point
     * -------------------------
     * This method starts the program and continuously displays
     * the main menu until the user chooses to exit.
     */
    public static void main(String[] args) {

        // Load sample data into the system when the program starts
        seedSampleData();

        boolean running = true;

        // Main application loop
        while (running) {

            printMainMenu();

            int choice = getIntInput();

            switch (choice) {

                case 1:
                    appointmentMenu();
                    break;

                case 2:
                    contactMenu();
                    break;

                case 3:
                    taskMenu();
                    break;

                case 4:
                    running = false;
                    System.out.println("Exiting program...");
                    break;

                default:
                    System.out.println("Invalid selection.");
            }
        }
    }

    /*
     * Displays the main navigation menu.
     */
    private static void printMainMenu() {

        System.out.println("\n============================");
        System.out.println(" Appointment Management System");
        System.out.println("============================");
        System.out.println("1. Manage Appointments");
        System.out.println("2. Manage Contacts");
        System.out.println("3. Manage Tasks");
        System.out.println("4. Exit");
        System.out.print("Select option: ");
    }

    /*
     * Appointment Menu
     * -------------------------
     * Provides options to create, update, delete, and view appointments.
     */
    private static void appointmentMenu() {

        System.out.println("\nAppointment Menu");
        System.out.println("1. Add Appointment");
        System.out.println("2. Delete Appointment");
        System.out.println("3. View All Appointments");

        int choice = getIntInput();

        switch (choice) {

            case 1:
                addAppointment();
                break;

            case 2:
                deleteAppointment();
                break;

            case 3:
                appointmentService.displayAllAppointments();
                break;
        }
    }

    /*
     * Adds a new appointment to the system.
     */
    private static void addAppointment() {

        try {

            System.out.print("Enter Appointment ID: ");
            String id = scanner.nextLine();

            System.out.print("Enter Description: ");
            String description = scanner.nextLine();

            // Use current system date
            Date date = new Date();

            appointmentService.addAppointment(
                    new Appointment(id, date, description)
            );

            System.out.println("Appointment added successfully.");

        } catch (Exception e) {

            System.out.println("Error: " + e.getMessage());
        }
    }

    /*
     * Deletes an appointment by ID.
     */
    private static void deleteAppointment() {

        System.out.print("Enter Appointment ID to delete: ");

        String id = scanner.nextLine();

        appointmentService.deleteAppointment(id);
    }

    /*
     * Contact Menu
     */
    private static void contactMenu() {

        System.out.println("\nContact Menu");
        System.out.println("1. Add Contact");
        System.out.println("2. Delete Contact");
        System.out.println("3. View All Contacts");

        int choice = getIntInput();

        switch (choice) {

            case 1:
                addContact();
                break;

            case 2:
                deleteContact();
                break;

            case 3:
                contactService.displayAllContacts();
                break;
        }
    }

    /*
     * Creates a new contact using user input.
     */
    private static void addContact() {

        try {

            System.out.print("Enter Contact ID: ");
            String id = scanner.nextLine();

            System.out.print("Enter First Name: ");
            String first = scanner.nextLine();

            System.out.print("Enter Last Name: ");
            String last = scanner.nextLine();

            System.out.print("Enter Phone (10 digits): ");
            String phone = scanner.nextLine();

            System.out.print("Enter Address: ");
            String address = scanner.nextLine();

            contactService.addContact(
                    new Contact(id, first, last, phone, address)
            );

            System.out.println("Contact added successfully.");

        } catch (Exception e) {

            System.out.println("Error: " + e.getMessage());
        }
    }

    /*
     * Deletes a contact using the contact ID.
     */
    private static void deleteContact() {

        System.out.print("Enter Contact ID to delete: ");

        String id = scanner.nextLine();

        contactService.deleteContact(id);
    }

    /*
     * Task Menu
     */
    private static void taskMenu() {

        System.out.println("\nTask Menu");
        System.out.println("1. Add Task");
        System.out.println("2. Delete Task");
        System.out.println("3. View All Tasks");

        int choice = getIntInput();

        switch (choice) {

            case 1:
                addTask();
                break;

            case 2:
                deleteTask();
                break;

            case 3:
                taskService.displayAllTasks();
                break;
        }
    }

    /*
     * Creates a new task.
     */
    private static void addTask() {

        try {

            System.out.print("Enter Task ID: ");
            String id = scanner.nextLine();

            System.out.print("Enter Task Name: ");
            String name = scanner.nextLine();

            System.out.print("Enter Description: ");
            String description = scanner.nextLine();

            taskService.addTask(
                    new Task(id, name, description)
            );

            System.out.println("Task added successfully.");

        } catch (Exception e) {

            System.out.println("Error: " + e.getMessage());
        }
    }

    /*
     * Deletes a task by ID.
     */
    private static void deleteTask() {

        System.out.print("Enter Task ID to delete: ");

        String id = scanner.nextLine();

        taskService.deleteTask(id);
    }

    /*
     * Helper method to safely read integer input.
     */
    private static int getIntInput() {

        int value = Integer.parseInt(scanner.nextLine());

        return value;
    }

    /*
     * Seeds initial test data into the system.
     * This allows the program to start with existing records,
     * which helps demonstrate system functionality immediately.
     */
    private static void seedSampleData() {

        appointmentService.seedAppointments();

        contactService.seedContacts();

        taskService.seedTasks();
    }
}