package cs320project;

import java.util.ArrayList;
import java.util.List;

/*
 * This service class manages all contact-related operations
 * within the system. It acts as the business logic layer
 * between the user interface (Main class) and the Contact
 * data model.
 *
 * Design Purpose:
 * The ContactService is responsible for storing, updating,
 * deleting, and displaying contact records while ensuring
 * that all data follows system validation rules.
 *
 * Responsibilities:
 * - Store contact records in memory
 * - Prevent duplicate contact IDs
 * - Add new contacts
 * - Delete contacts
 * - Update contact information
 * - Display contact records
 *
 * Software Design Principles Used:
 * - Encapsulation
 * - Separation of concerns
 * - Data validation
 * - Maintainability
 * - Readability
 */

public class ContactService {

    /*
     * Data Storage
     * --------------------------------------------------------
     * The ArrayList stores all contact objects in memory.
     *
     * Why ArrayList?
     * - Automatically resizes as data grows
     * - Provides fast iteration
     * - Simple and efficient for small datasets
     * - Meets project requirements
     */
    private List<Contact> contacts =
            new ArrayList<>();

    /*
     * addContact Method
     * --------------------------------------------------------
     * Adds a new contact to the system.
     *
     * Validation Performed:
     * - Ensures the contact ID is unique
     *
     * If a duplicate ID is detected, the system throws
     * an IllegalArgumentException to prevent data conflicts.
     */
    public void addContact(Contact contact) {

        // Loop through existing contacts
        for (Contact existing : contacts) {

            // Check for duplicate ID
            if (existing.getContactId()
                    .equals(contact.getContactId())) {

                throw new IllegalArgumentException(
                        "Contact ID already exists."
                );
            }
        }

        // Add the new contact to the list
        contacts.add(contact);
    }

    /*
     * deleteContact Method
     * --------------------------------------------------------
     * Removes a contact from the system using the contact ID.
     *
     * Behavior:
     * - Searches the list for a matching ID
     * - Displays a message if not found
     */
    public void deleteContact(String contactId) {
        
    	Contact toRemove = getContact(contactId);
        
        if (toRemove != null) {
        
        	contacts.remove(toRemove);
            
        	System.out.println("Contact deleted successfully.");
        
        } else {
        
        	throw new IllegalArgumentException("Contact ID not found.");
        
        }
    }

    /*
     * updateContact Method
     * --------------------------------------------------------
     * Updates an existing contact's information.
     *
     * Fields that can be updated:
     * - First name
     * - Last name
     * - Phone number
     * - Address
     *
     * This method demonstrates controlled modification
     * of object data using setter methods from the Contact
     * class, which ensures validation rules are enforced.
     */
    public void updateContact(
            String contactId,
            String firstName,
            String lastName,
            String phone,
            String address) {

        // Search for the contact
        for (Contact contact : contacts) {

            if (contact.getContactId()
                    .equals(contactId)) {

                /*
                 * Each setter performs validation inside
                 * the Contact class. This ensures that
                 * invalid data cannot be stored.
                 */

                if (firstName != null) {
                    contact.setFirstName(firstName);
                }

                if (lastName != null) {
                    contact.setLastName(lastName);
                }

                if (phone != null) {
                    contact.setPhone(phone);
                }

                if (address != null) {
                    contact.setAddress(address);
                }

                System.out.println(
                        "Contact updated successfully."
                );

                return;
            }
        }

        // Contact not found
        System.out.println(
                "Contact ID not found."
        );
    }

    /*
     * displayAllContacts Method
     * --------------------------------------------------------
     * Displays all contacts currently stored in the system.
     *
     * This method is useful for:
     * - Debugging
     * - Demonstration
     * - System verification
     */
    public void displayAllContacts() {

        // Check if list is empty
        if (contacts.isEmpty()) {

            System.out.println(
                    "No contacts found."
            );

            return;
        }

        System.out.println("\nCurrent Contacts:");

        // Loop through contacts
        for (Contact contact : contacts) {

            System.out.println(
                    "ID: " +
                    contact.getContactId()
            );

            System.out.println(
                    "First Name: " +
                    contact.getFirstName()
            );

            System.out.println(
                    "Last Name: " +
                    contact.getLastName()
            );

            System.out.println(
                    "Phone: " +
                    contact.getPhone()
            );

            System.out.println(
                    "Address: " +
                    contact.getAddress()
            );

            System.out.println("----------------------");
        }
    }

    /*
     * seedContacts Method
     * --------------------------------------------------------
     * This method preloads sample contact data into the system
     * when the program starts.
     *
     * Purpose:
     * - Demonstrates system functionality immediately
     * - Provides realistic test data
     * - Helps validate system behavior
     * - Supports debugging and testing
     */
    public void seedContacts() {

        try {

            contacts.add(
                    new Contact(
                            "C001",
                            "John",
                            "Smith",
                            "5551234567",
                            "123 Main Street"
                    )
            );

            contacts.add(
                    new Contact(
                            "C002",
                            "Sarah",
                            "Johnson",
                            "5552345678",
                            "456 Oak Avenue"
                    )
            );

            contacts.add(
                    new Contact(
                            "C003",
                            "Michael",
                            "Brown",
                            "5553456789",
                            "789 Pine Road"
                    )
            );

            contacts.add(
                    new Contact(
                            "C004",
                            "Emily",
                            "Davis",
                            "5554567890",
                            "321 Maple Drive"
                    )
            );

            contacts.add(
                    new Contact(
                            "C005",
                            "David",
                            "Wilson",
                            "5555678901",
                            "654 Cedar Lane"
                    )
            );

        } catch (Exception e) {

            /*
             * Exception Handling
             * ------------------------------------------------
             * If sample data fails validation, the system logs
             * the error instead of terminating the program.
             */

            System.out.println(
                    "Error seeding contacts: "
                    + e.getMessage()
            );
        }
    }
    
    /*
     * getContact Method
     * --------------------------------------------------------
     * Retrieves a contact from the system using the contact ID.
     *
     * Returns:
     * - The Contact object if found
     * - null if the contact does not exist
     *
     * This method is required for unit testing and verification
     * of stored contact records.
     */
    public Contact getContact(String contactId) {

        // Search for matching contact
        for (Contact contact : contacts) {

            if (contact.getContactId()
                    .equals(contactId)) {

                return contact;
            }
        }

        // Contact not found
        return null;
    }
}