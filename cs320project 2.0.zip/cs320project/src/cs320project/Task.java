package cs320project;

public class Task {
	private final String taskId; // Unique task ID
    private String name; // Task name
    private String description; // Task description 

    //constructor with validation checks
    public Task(String taskId, String name, String description) {
        if (taskId == null || taskId.length() > 10) {
            throw new IllegalArgumentException("Task ID must be non-null and up to 10 characters.");
        }
        if (name == null || name.length() > 20) {
            throw new IllegalArgumentException("Name must be non-null and up to 20 characters.");
        }
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Description must be non-null and up to 50 characters.");
        }
        this.taskId = taskId;
        this.name = name;
        this.description = description;
    }
    
    // Getter for task ID
    public String getTaskId() {
        return taskId;
    }
    
    // Getter and setter for name
    public String getName() {
        return name;
    }

    public void setName(String name) {
        if (name == null || name.length() > 20) {
            throw new IllegalArgumentException("Name must be non-null and up to 20 characters.");
        }
        this.name = name;
    }

    // Getter and setter for description
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Description must be non-null and up to 50 characters.");
        }
        this.description = description;
    }

}
