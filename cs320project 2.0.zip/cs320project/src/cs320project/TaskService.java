package cs320project;

import java.util.ArrayList;
import java.util.List;

/*
 * TaskService.java
 * --------------------------------------------------------
 * This service class manages all task-related operations
 * within the system. It serves as the business logic layer
 * between the user interface (Main class) and the Task
 * data model.
 *
 * Design Purpose:
 * The TaskService ensures that task records are stored,
 * updated, deleted, and displayed correctly while enforcing
 * validation and preventing duplicate task IDs.
 *
 * Responsibilities:
 * - Store task records in memory
 * - Prevent duplicate task IDs
 * - Add new tasks
 * - Delete tasks
 * - Update task information
 * - Display task records
 *
 * Software Design Principles Used:
 * - Encapsulation
 * - Separation of concerns
 * - Data validation
 * - Maintainability
 * - Readability
 */

public class TaskService {

    /*
     * Data Storage
     * --------------------------------------------------------
     * The ArrayList stores all task objects in memory.
     *
     * Why ArrayList?
     * - Automatically resizes as tasks are added
     * - Allows efficient iteration
     * - Simple implementation for in-memory storage
     * - Meets project requirements
     */
    private List<Task> tasks =
            new ArrayList<>();

    /*
     * addTask Method
     * --------------------------------------------------------
     * Adds a new task to the system.
     *
     * Validation Performed:
     * - Ensures the task ID is unique
     *
     * If a duplicate ID is detected, the system throws
     * an IllegalArgumentException to prevent data conflicts.
     */
    public void addTask(Task task) {

        // Loop through existing tasks
        for (Task existing : tasks) {

            // Check for duplicate task ID
            if (existing.getTaskId()
                    .equals(task.getTaskId())) {

                throw new IllegalArgumentException(
                        "Task ID already exists."
                );
            }
        }

        // Add the new task to the list
        tasks.add(task);
    }

    /*
     * deleteTask Method
     * --------------------------------------------------------
     * Removes a task from the system using the task ID.
     *
     * Behavior:
     * - Searches the list for a matching ID
     * - Displays a message if not found
     */
    public void deleteTask(String taskId) {
       
    	Task toRemove = getTask(taskId);
        if (toRemove != null) {
            
        	tasks.remove(toRemove);
        
            System.out.println("Task deleted successfully.");
        
        } else {
            
        	throw new IllegalArgumentException("Task ID not found.");
        }
    }

    /*
     * updateTask Method
     * --------------------------------------------------------
     * Updates an existing task's information.
     *
     * Fields that can be updated:
     * - Task name
     * - Task description
     *
     * This method demonstrates controlled modification
     * of object data using setter methods from the Task
     * class, which ensures validation rules are enforced.
     */
    public void updateTask(
            String taskId,
            String name,
            String description) {

        // Search for the task
        for (Task task : tasks) {

            if (task.getTaskId()
                    .equals(taskId)) {

                /*
                 * Each setter method inside the Task class
                 * performs validation to ensure that:
                 * - Name is not null
                 * - Name does not exceed length limits
                 * - Description is not null
                 * - Description meets length requirements
                 */

                if (name != null) {
                    task.setName(name);
                }

                if (description != null) {
                    task.setDescription(description);
                }

                System.out.println(
                        "Task updated successfully."
                );

                return;
            }
        }

        // Task not found
        System.out.println(
                "Task ID not found."
        );
    }

    /*
     * displayAllTasks Method
     * --------------------------------------------------------
     * Displays all tasks currently stored in the system.
     *
     * This method is useful for:
     * - Debugging
     * - Demonstration
     * - System verification
     */
    public void displayAllTasks() {

        // Check if list is empty
        if (tasks.isEmpty()) {

            System.out.println(
                    "No tasks found."
            );

            return;
        }

        System.out.println("\nCurrent Tasks:");

        // Loop through tasks
        for (Task task : tasks) {

            System.out.println(
                    "ID: " +
                    task.getTaskId()
            );

            System.out.println(
                    "Name: " +
                    task.getName()
            );

            System.out.println(
                    "Description: " +
                    task.getDescription()
            );

            System.out.println("----------------------");
        }
    }

    /*
     * seedTasks Method
     * --------------------------------------------------------
     * This method preloads sample task data into the system
     * when the program starts.
     *
     * Purpose:
     * - Demonstrates system functionality immediately
     * - Provides realistic test data
     * - Helps validate system behavior
     * - Supports debugging and testing
     */
    public void seedTasks() {

        try {

            tasks.add(
                    new Task(
                            "T001",
                            "Complete Report",
                            "Finish the quarterly report"
                    )
            );

            tasks.add(
                    new Task(
                            "T002",
                            "Team Meeting",
                            "Attend weekly team meeting"
                    )
            );

            tasks.add(
                    new Task(
                            "T003",
                            "Code Review",
                            "Review pull requests"
                    )
            );

            tasks.add(
                    new Task(
                            "T004",
                            "System Testing",
                            "Run system validation tests"
                    )
            );

            tasks.add(
                    new Task(
                            "T005",
                            "Client Follow-Up",
                            "Contact client for feedback"
                    )
            );

        } catch (Exception e) {

            /*
             * Exception Handling
             * ------------------------------------------------
             * If sample data fails validation, the system logs
             * the error instead of terminating the program.
             */

            System.out.println(
                    "Error seeding tasks: "
                    + e.getMessage()
            );
        }
    }
    
    /*
     * getTask Method
     * --------------------------------------------------------
     * Retrieves a task by its unique ID.
     *
     * Returns:
     * - Task object if found
     * - null if the task does not exist
     *
     * Purpose:
     * - Supports unit testing and verification
     * - Allows other classes to access task details safely
     */
    public Task getTask(String taskId) {
        for (Task task : tasks) {
            if (task.getTaskId().equals(taskId)) {
                return task;
            }
        }
        return null; // Task not found
    }

    /*
     * updateTaskName Method
     * --------------------------------------------------------
     * Updates only the name of a task.
     *
     * Parameters:
     * - taskId: The unique ID of the task to update
     * - newName: The new task name to assign
     *
     * This method allows updating the name without affecting
     * the description.
     */
    public void updateTaskName(String taskId, String newName) {
        Task task = getTask(taskId);
        if (task != null) {
            task.setName(newName);
            System.out.println("Task name updated successfully.");
        } else {
            System.out.println("Task ID not found.");
        }
    }

    /*
     * updateTaskDescription Method
     * --------------------------------------------------------
     * Updates only the description of a task.
     *
     * Parameters:
     * - taskId: The unique ID of the task to update
     * - newDescription: The new description to assign
     *
     * This method allows updating the description without
     * affecting the task name.
     */
    public void updateTaskDescription(String taskId, String newDescription) {
        Task task = getTask(taskId);
        if (task != null) {
            task.setDescription(newDescription);
            System.out.println("Task description updated successfully.");
        } else {
            System.out.println("Task ID not found.");
        }
    }
}