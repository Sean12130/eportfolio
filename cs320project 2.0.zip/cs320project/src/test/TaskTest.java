package test;

import org.junit.jupiter.api.Test;

import cs320project.Task;

import static org.junit.jupiter.api.Assertions.*;


public class TaskTest {
	// Test valid task creation
		@Test
	    public void testTaskCreationValid() {
	        Task task = new Task("12345", "Task Name", "Task Description");
	        assertEquals("12345", task.getTaskId());
	        assertEquals("Task Name", task.getName());
	        assertEquals("Task Description", task.getDescription());
	    }

		// Test invalid task ID 
	    @Test
	    public void testTaskInvalidId() {
	        assertThrows(IllegalArgumentException.class, () -> new Task(null, "Task Name", "Task Description"));
	        assertThrows(IllegalArgumentException.class, () -> new Task("12345678901", "Task Name", "Task Description"));
	    }

	    // Test invalid name 
	    @Test
	    public void testTaskInvalidName() {
	        assertThrows(IllegalArgumentException.class, () -> new Task("12345", null, "Task Description"));
	        assertThrows(IllegalArgumentException.class, () -> new Task("12345", "This name is definitely way too long", "Task Description"));
	    }

	    // Test invalid description
	    @Test
	    public void testTaskInvalidDescription() {
	        assertThrows(IllegalArgumentException.class, () -> new Task("12345", "Task Name", null));
	        assertThrows(IllegalArgumentException.class, () -> new Task("12345", "Task Name", "This description is going to exceed the maximum limit of fifty characters, so it should fail."));
	    }

}
