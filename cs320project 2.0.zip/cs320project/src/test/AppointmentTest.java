package test;

import org.junit.jupiter.api.Test;

import cs320project.Appointment;

import java.util.Date;
import java.util.Calendar;
import static org.junit.jupiter.api.Assertions.*;

public class AppointmentTest {
	@Test
    public void testValidAppointment() {
        // Create a future date for the appointment
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, 1);
        Date futureDate = cal.getTime();

        // Create a valid appointment instance
        Appointment appointment = new Appointment("12345", futureDate, "Doctor's appointment");
        
        // Verify that the appointment fields match expected values
        assertEquals("12345", appointment.getAppointmentId());
        assertEquals(futureDate, appointment.getAppointmentDate());
        assertEquals("Doctor's appointment", appointment.getDescription());
    }

    @Test
    public void testInvalidAppointmentId() {
        // Create a future date for testing
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, 1);
        Date futureDate = cal.getTime();

        // Test for null appointment ID
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(null, futureDate, "Valid description");
        });

        // Test for appointment ID exceeding 10 characters
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345678901", futureDate, "Valid description");
        });
    }

    @Test
    public void testInvalidAppointmentDate() {
        // Create a past date for testing
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, -1);
        Date pastDate = cal.getTime();

        // Test for a past appointment date
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345", pastDate, "Valid description");
        });

        // Test for a null appointment date
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345", null, "Valid description");
        });
    }

    @Test
    public void testInvalidDescription() {
        // Create a future date for testing
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, 1);
        Date futureDate = cal.getTime();

        // Test for null description
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345", futureDate, null);
        });

        // Test for description exceeding 50 characters
        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345", futureDate, "This description is way too long and should not be accepted.");
        });
    }

}
