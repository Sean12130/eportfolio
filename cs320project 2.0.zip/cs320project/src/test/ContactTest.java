package test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import cs320project.Contact;

public class ContactTest {
	 // test valid Contact object creation
    @Test
    public void testValidContact() {
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Main St");
        assertEquals("12345", contact.getContactId());
        assertEquals("John", contact.getFirstName());
        assertEquals("Doe", contact.getLastName());
        assertEquals("1234567890", contact.getPhone());
        assertEquals("123 Main St", contact.getAddress());
    }

    // constructor tests 
    
    // test contact ID cannot be null
    @Test
    public void testNullContactId() {
        assertThrows(IllegalArgumentException.class, () -> new Contact(null, "John", "Doe", "1234567890", "123 Main St"));
    }

    // test contact ID cannot exceed 10 characters
    @Test
    public void testContactIdTooLong() {
        assertThrows(IllegalArgumentException.class, () -> new Contact("12345678901", "John", "Doe", "1234567890", "123 Main St"));
    }

    // test first name cannot be null
    @Test
    public void testNullFirstName() {
        assertThrows(IllegalArgumentException.class, () -> new Contact("123", null, "Doe", "1234567890", "123 Main St"));
    }

    // test first name cannot exceed 10 characters
    @Test
    public void testFirstNameTooLong() {
        assertThrows(IllegalArgumentException.class, () -> new Contact("123", "JohnathanDoe", "Doe", "1234567890", "123 Main St"));
    }

    // test last name cannot be null
    @Test
    public void testNullLastName() {
        assertThrows(IllegalArgumentException.class, () -> new Contact("123", "John", null, "1234567890", "123 Main St"));
    }

    // test last name cannot exceed 10 characters
    @Test
    public void testLastNameTooLong() {
        assertThrows(IllegalArgumentException.class, () -> new Contact("123", "John", "DoeTheThird", "1234567890", "123 Main St"));
    }

    // test phone number cannot be null
    @Test
    public void testNullPhone() {
        assertThrows(IllegalArgumentException.class, () -> new Contact("123", "John", "Doe", null, "123 Main St"));
    }

    // test phone number must be exactly 10 digits
    @Test
    public void testInvalidPhoneLength() {
        assertThrows(IllegalArgumentException.class, () -> new Contact("123", "John", "Doe", "12345", "123 Main St"));
    }

    // test phone number must contain only digits
    @Test
    public void testPhoneContainsNonDigits() {
        assertThrows(IllegalArgumentException.class, () -> new Contact("123", "John", "Doe", "12345abcde", "123 Main St"));
    }

    // test address cannot be null
    @Test
    public void testNullAddress() {
        assertThrows(IllegalArgumentException.class, () -> new Contact("123", "John", "Doe", "1234567890", null));
    }

    // test address cannot exceed 30 characters
    @Test
    public void testAddressTooLong() {
        assertThrows(IllegalArgumentException.class, () -> new Contact("123", "John", "Doe", "1234567890", "123 Main Street, Some Big City, State 99999"));
    }

    // setter tests 
    
    // test valid first name update
    @Test
    public void testSetFirstNameValid() {
        Contact contact = new Contact("123", "John", "Doe", "1234567890", "123 Main St");
        contact.setFirstName("Jane");
        assertEquals("Jane", contact.getFirstName());
    }

    // test first name cannot be null when updating
    @Test
    public void testSetFirstNameNull() {
        Contact contact = new Contact("123", "John", "Doe", "1234567890", "123 Main St");
        assertThrows(IllegalArgumentException.class, () -> contact.setFirstName(null));
    }

    // test first name cannot exceed 10 characters when updating
    @Test
    public void testSetFirstNameTooLong() {
        Contact contact = new Contact("123", "John", "Doe", "1234567890", "123 Main St");
        assertThrows(IllegalArgumentException.class, () -> contact.setFirstName("JohnathanDoe"));
    }

    // test valid last name update
    @Test
    public void testSetLastNameValid() {
        Contact contact = new Contact("123", "John", "Doe", "1234567890", "123 Main St");
        contact.setLastName("Smith");
        assertEquals("Smith", contact.getLastName());
    }

    // test last name cannot be null when updating
    @Test
    public void testSetLastNameNull() {
        Contact contact = new Contact("123", "John", "Doe", "1234567890", "123 Main St");
        assertThrows(IllegalArgumentException.class, () -> contact.setLastName(null));
    }

    // test last name cannot exceed 10 characters when updating
    @Test
    public void testSetLastNameTooLong() {
        Contact contact = new Contact("123", "John", "Doe", "1234567890", "123 Main St");
        assertThrows(IllegalArgumentException.class, () -> contact.setLastName("DoeTheThird"));
    }

    // test valid phone update
    @Test
    public void testSetPhoneValid() {
        Contact contact = new Contact("123", "John", "Doe", "1234567890", "123 Main St");
        contact.setPhone("0987654321");
        assertEquals("0987654321", contact.getPhone());
    }

    // test phone number cannot be null when updating
    @Test
    public void testSetPhoneNull() {
        Contact contact = new Contact("123", "John", "Doe", "1234567890", "123 Main St");
        assertThrows(IllegalArgumentException.class, () -> contact.setPhone(null));
    }

    // test phone number must be exactly 10 digits when updating
    @Test
    public void testSetPhoneInvalidLength() {
        Contact contact = new Contact("123", "John", "Doe", "1234567890", "123 Main St");
        assertThrows(IllegalArgumentException.class, () -> contact.setPhone("12345"));
    }

    // test phone number cannot contain non-numeric characters when updating
    @Test
    public void testSetPhoneNonDigits() {
        Contact contact = new Contact("123", "John", "Doe", "1234567890", "123 Main St");
        assertThrows(IllegalArgumentException.class, () -> contact.setPhone("12345abcde"));
    }

    // test valid address update
    @Test
    public void testSetAddressValid() {
        Contact contact = new Contact("123", "John", "Doe", "1234567890", "123 Main St");
        contact.setAddress("456 Elm St");
        assertEquals("456 Elm St", contact.getAddress());
    }

    // test address cannot be null when updating
    @Test
    public void testSetAddressNull() {
        Contact contact = new Contact("123", "John", "Doe", "1234567890", "123 Main St");
        assertThrows(IllegalArgumentException.class, () -> contact.setAddress(null));
    }

    // test address cannot exceed 30 characters when updating
    @Test
    public void testSetAddressTooLong() {
        Contact contact = new Contact("123", "John", "Doe", "1234567890", "123 Main St");
        assertThrows(IllegalArgumentException.class, () -> contact.setAddress("1234567890123456789012345678901"));
    }
}
