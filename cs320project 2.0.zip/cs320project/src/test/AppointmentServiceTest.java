package test;

import org.junit.jupiter.api.Test;

import cs320project.Appointment;
import cs320project.AppointmentService;

import java.util.Calendar;
import java.util.Date;
import static org.junit.jupiter.api.Assertions.*;

public class AppointmentServiceTest {
	@Test
    public void testAddAppointment() {
        // Create an appointment service instance
        AppointmentService service = new AppointmentService();
        
        // Create a future date for the appointment
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, 1);
        Date futureDate = cal.getTime();

        // Create an appointment and add it to the service
        Appointment appointment = new Appointment("12345", futureDate, "Doctor visit");
        service.addAppointment(appointment);

        // Verify that the appointment was successfully added
        assertEquals(appointment, service.getAppointment("12345"));
    }

    @Test
    public void testAddDuplicateAppointmentId() {
        // Create an appointment service instance
        AppointmentService service = new AppointmentService();
        
        // Create a future date for testing
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, 1);
        Date futureDate = cal.getTime();

        // Create two appointments with the same ID
        Appointment appointment1 = new Appointment("12345", futureDate, "First appointment");
        Appointment appointment2 = new Appointment("12345", futureDate, "Second appointment");

        // Add the first appointment successfully
        service.addAppointment(appointment1);

        // Adding the second appointment should throw an exception due to duplicate ID
        assertThrows(IllegalArgumentException.class, () -> {
            service.addAppointment(appointment2);
        });
    }

    @Test
    public void testDeleteAppointment() {
        // Create an appointment service instance
        AppointmentService service = new AppointmentService();
        
        // Create a future date for testing
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, 1);
        Date futureDate = cal.getTime();

        // Create an appointment and add it to the service
        Appointment appointment = new Appointment("12345", futureDate, "Doctor visit");
        service.addAppointment(appointment);

        // Delete the appointment
        service.deleteAppointment("12345");

        // Verify that the appointment is no longer in the service
        assertNull(service.getAppointment("12345"));
    }

    @Test
    public void testDeleteNonExistentAppointment() {
        // Create an appointment service instance
        AppointmentService service = new AppointmentService();

        // Attempting to delete a non-existent appointment should throw an exception
        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteAppointment("99999");
        });
    }

}
