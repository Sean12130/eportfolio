package test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import cs320project.Contact;
import cs320project.ContactService;


public class ContactServiceTest {
	private ContactService service;
    
    @BeforeEach
    public void setUp() {
        service = new ContactService();
    }
    
    @Test
    public void testAddContact() {
        Contact contact = new Contact("123", "John", "Doe", "1234567890", "123 Main St");
        service.addContact(contact);
        assertEquals(contact, service.getContact("123"));
    }
    
    @Test
    public void testDeleteContact() {
        Contact contact = new Contact("123", "John", "Doe", "1234567890", "123 Main St");
        service.addContact(contact);
        service.deleteContact("123");
        assertNull(service.getContact("123"));
    }
    
    @Test
    public void testUpdateContact() {
        Contact contact = new Contact("123", "John", "Doe", "1234567890", "123 Main St");
        service.addContact(contact);
        service.updateContact("123", "Jane", null, null, "456 Oak St");
        assertEquals("Jane", service.getContact("123").getFirstName());
        assertEquals("456 Oak St", service.getContact("123").getAddress());
    }

}
