package test;

import org.junit.jupiter.api.Test;

import cs320project.Task;
import cs320project.TaskService;

import static org.junit.jupiter.api.Assertions.*;

public class TaskServiceTest {
	// Test adding a new task
		@Test
	    public void testAddTask() {
	        TaskService service = new TaskService();
	        Task task = new Task("12345", "Test Task", "Test Description");
	        service.addTask(task);
	        assertThrows(IllegalArgumentException.class, () -> service.addTask(task));
	    }

		// Test deleting a task
	    @Test
	    public void testDeleteTask() {
	        TaskService service = new TaskService();
	        Task task = new Task("12345", "Test Task", "Test Description");
	        service.addTask(task);
	        service.deleteTask("12345");
	        assertThrows(IllegalArgumentException.class, () -> service.deleteTask("12345"));
	    }

	    // Test updating a task's name
	    @Test
	    public void testUpdateTaskName() {
	        TaskService service = new TaskService();
	        Task task = new Task("12345", "Test Task", "Test Description");
	        service.addTask(task);
	        service.updateTaskName("12345", "Updated Name");
	        assertEquals("Updated Name", task.getName());
	    }

	    // Test updating a task's description
	    @Test
	    public void testUpdateTaskDescription() {
	        TaskService service = new TaskService();
	        Task task = new Task("12345", "Test Task", "Test Description");
	        service.addTask(task);
	        service.updateTaskDescription("12345", "Updated Description");
	        assertEquals("Updated Description", task.getDescription());
	    }

}
