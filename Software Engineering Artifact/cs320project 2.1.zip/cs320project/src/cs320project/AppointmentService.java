package cs320project;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/*
 * This service class is responsible for managing all
 * appointment-related operations within the system.
 *
 * Design Purpose:
 * The AppointmentService acts as the business logic layer
 * between the user interface (Main class) and the data model
 * (Appointment class).
 *
 * Responsibilities:
 * - Store appointment records
 * - Prevent duplicate appointment IDs
 * - Add new appointments
 * - Delete existing appointments
 * - Display appointment information
 *
 * Software Design Principles Used:
 * - Encapsulation
 * - Separation of concerns
 * - Data validation
 * - Maintainability
 */

public class AppointmentService {

    /*
     * Data Storage
     * --------------------------------------------------------
     * The ArrayList stores all appointment objects in memory.
     *
     * Why ArrayList?
     * - Dynamic resizing
     * - Fast iteration
     * - Simple implementation
     * - Meets project requirements
     */
    private List<Appointment> appointments =
            new ArrayList<>();

    /*
     * addAppointment Method
     * --------------------------------------------------------
     * Adds a new appointment to the system.
     *
     * Validation Performed:
     * - Appointment ID must be unique
     *
     * If a duplicate ID is detected, the system throws
     * an IllegalArgumentException to prevent data corruption.
     */
    public void addAppointment(Appointment appointment) {
    	
    	/*
         * =========================
         * IMPROVEMENT 
         * =========================
         * Prevents null objects from entering system.
         * Strengthens system reliability.
         */
        if (appointment == null || appointment.getAppointmentId() == null) {
        	throw new IllegalArgumentException("Appointment or ID cannot be null");
        }

        // Check for duplicate appointment ID
        for (Appointment existing : appointments) {

        	/*
             * =========================
             * IMPROVEMENT 
             * =========================
             * Ensures safe comparison even if stored data is incomplete.
             */

        	if (existing.getAppointmentId() != null &&
        		existing.getAppointmentId().equals(appointment.getAppointmentId())) {

        		throw new IllegalArgumentException("Appointment ID already exists.");
        	}
        }

        // Add appointment to list
        appointments.add(appointment);
    }

    /*
     * deleteAppointment Method
     * --------------------------------------------------------
     * Removes an appointment from the system using the
     * appointment ID.
     *
     * Behavior:
     * - Searches the list for a matching ID
     * - Removes the appointment if found
     * - Displays a message if not found
     */
    public void deleteAppointment(String appointmentId) {
    	
    	/*
         * =========================
         * IMPROVEMENT 
         * =========================
         * Prevents empty or invalid IDs from being processed.
         */
    	if (appointmentId == null || appointmentId.trim().isEmpty()) {
    		throw new IllegalArgumentException("Appointment ID cannot be empty");
    	}
    	
    	Appointment toRemove = getAppointment(appointmentId);
        if (toRemove != null) {
        
        	appointments.remove(toRemove);
            
        	System.out.println("Appointment deleted successfully.");
        
        } else {
        
        	throw new IllegalArgumentException("Appointment ID not found.");
        }
    }

    
    /*
     * getAppointment Method
     * --------------------------------------------------------
     * Retrieves an appointment from the system using the
     * appointment ID.
     *
     * Returns:
     * - The Appointment object if found
     * - null if the appointment does not exist
     *
     * This method is required for unit testing and verification
     * of stored appointment records.
     */
    public Appointment getAppointment(String appointmentId) {

        // Search for matching appointment
        for (Appointment appointment : appointments) {

            if (appointment.getAppointmentId()
                    .equals(appointmentId)) {

                return appointment;
            }
        }

        // Appointment not found
        return null;
    }
    
    /*
     * displayAllAppointments Method
     * --------------------------------------------------------
     * Displays every appointment currently stored in the system.
     *
     * This method is primarily used for:
     * - Debugging
     * - System verification
     * - Demonstration of functionality
     */
    public void displayAllAppointments() {

        if (appointments.isEmpty()) {

            System.out.println(
                    "No appointments found."
            );

            return;
        }

        System.out.println("\nCurrent Appointments:");

        for (Appointment appointment : appointments) {

            System.out.println(
                    "ID: " +
                    appointment.getAppointmentId()
            );

            System.out.println(
                    "Date: " +
                    appointment.getAppointmentDate()
            );

            System.out.println(
                    "Description: " +
                    appointment.getDescription()
            );

            System.out.println("----------------------");
        }
    }

    /*
     * seedAppointments Method
     * --------------------------------------------------------
     * This method preloads sample appointment data into the
     * system at startup.
     *
     * Purpose:
     * - Demonstrates system functionality immediately
     * - Provides realistic test data
     * - Helps validate system behavior
     */
    public void seedAppointments() {

        try {

            appointments.add(
                    new Appointment(
                            "A001",
                            new Date(),
                            "Dental Checkup"
                    )
            );

            appointments.add(
                    new Appointment(
                            "A002",
                            new Date(),
                            "Team Meeting"
                    )
            );

            appointments.add(
                    new Appointment(
                            "A003",
                            new Date(),
                            "Project Review"
                    )
            );

            appointments.add(
                    new Appointment(
                            "A004",
                            new Date(),
                            "Client Consultation"
                    )
            );

            appointments.add(
                    new Appointment(
                            "A005",
                            new Date(),
                            "Performance Evaluation"
                    )
            );

        } catch (Exception e) {

            /*
             * Exception Handling
             * ------------------------------------------------
             * If any sample data fails validation, the system
             * logs the error instead of crashing.
             */

            System.out.println(
                    "Error seeding appointments: "
                    + e.getMessage()
            );
        }
    }

}