package cs320project;

import java.util.HashMap;
import java.util.Map;

public class TaskService {
	private final Map<String, Task> taskMap = new HashMap<>(); // in memory storage for tasks

	// Adds a new task to the service.
    public void addTask(Task task) {
        if (taskMap.containsKey(task.getTaskId())) {
            throw new IllegalArgumentException("Task ID must be unique.");
        }
        taskMap.put(task.getTaskId(), task);
    }

    // Deletes a task by its ID.
    public void deleteTask(String taskId) {
        if (!taskMap.containsKey(taskId)) {
            throw new IllegalArgumentException("Task ID not found.");
        }
        taskMap.remove(taskId);
    }

    // Update task by ID
    public void updateTaskName(String taskId, String newName) {
        if (!taskMap.containsKey(taskId)) {
            throw new IllegalArgumentException("Task ID not found.");
        }
        taskMap.get(taskId).setName(newName);
    }

    // Updates the description of a task by ID
    public void updateTaskDescription(String taskId, String newDescription) {
        if (!taskMap.containsKey(taskId)) {
            throw new IllegalArgumentException("Task ID not found.");
        }
        taskMap.get(taskId).setDescription(newDescription);
    }

}
