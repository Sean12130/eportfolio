package cs320project;

import java.util.Date;

// Sean Lant
// 02/16/2025

public class Appointment {
	// Final fields to ensure immutability of appointment ID
    private final String appointmentId;
    private final Date appointmentDate;
    private final String description;

    // Constructor with validation for all fields
    public Appointment(String appointmentId, Date appointmentDate, String description) {
        // Validate appointment ID: must not be null and must be at most 10 characters
        if (appointmentId == null || appointmentId.length() > 10) {
            throw new IllegalArgumentException("Appointment ID must be non-null and up to 10 characters long.");
        }
        
        // Validate appointment date: must not be null and must be in the future
        if (appointmentDate == null || appointmentDate.before(new Date())) {
            throw new IllegalArgumentException("Appointment date must be in the future and non-null.");
        }

        // Validate description: must not be null and must be at most 50 characters
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Description must be non-null and up to 50 characters long.");
        }

        // Assign validated values to final fields
        this.appointmentId = appointmentId;
        this.appointmentDate = appointmentDate;
        this.description = description;
    }

    // Getter for appointment ID 
    public String getAppointmentId() {
        return appointmentId;
    }

    // Getter for appointment date
    public Date getAppointmentDate() {
        return appointmentDate;
    }

    // Getter for description
    public String getDescription() {
        return description;
    }

}
