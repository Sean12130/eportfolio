package cs320project;

import java.util.HashMap;
import java.util.Map;

public class AppointmentService {
	// In-memory storage for appointments using a HashMap 
    private final Map<String, Appointment> appointments = new HashMap<>();

    // Method to add a new appointment
    public void addAppointment(Appointment appointment) {
        // Ensure the appointment ID is unique
        if (appointments.containsKey(appointment.getAppointmentId())) {
            throw new IllegalArgumentException("Appointment ID already exists.");
        }
        // Store the appointment in the HashMap
        appointments.put(appointment.getAppointmentId(), appointment);
    }

    // Method to delete an appointment using its ID
    public void deleteAppointment(String appointmentId) {
        // Ensure the appointment ID exists before attempting to delete
        if (!appointments.containsKey(appointmentId)) {
            throw new IllegalArgumentException("Appointment ID not found.");
        }
        // Remove the appointment from the HashMap
        appointments.remove(appointmentId);
    }

    // Method to retrieve an appointment by ID 
    public Appointment getAppointment(String appointmentId) {
        return appointments.get(appointmentId);
    }

}
