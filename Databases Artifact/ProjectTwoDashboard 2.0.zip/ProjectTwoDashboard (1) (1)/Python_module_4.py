
from pymongo import MongoClient
from pymongo.errors import PyMongoError


"""
AnimalShelter CRUD Module
--------------------------------------------------------
Provides Create, Read, Update, and Delete (CRUD) operations
for the MongoDB Animal Shelter database.

Supports authenticated access using role-based users.
Handles database connection setup and basic error handling.
"""


class AnimalShelter:
    """
    AnimalShelter Class
    --------------------------------------------------------
    Initializes the MongoDB connection and provides methods
    to interact with the 'animals' collection.
    """

    """
    Constructor
    --------------------------------------------------------
    Establishes a connection to the MongoDB database using
    provided credentials and stores references to the
    database and collection.
    """

    def __init__(self, username, password, host, port, db_name):

        # Store connection credentials
        self.username = username
        self.password = password
        self.host = host
        self.port = port
        self.db_name = db_name

        # Default collection name
        self.collection_name = "animals"

        try:
            # Create MongoDB client connection
            self.client = MongoClient(
                f"mongodb://{username}:{password}@{host}:{port}/?authSource=admin"
            )

            # Access database
            self.db = self.client[db_name]

            # Access collection
            self.collection = self.db[self.collection_name]

        except PyMongoError as e:
            print("MongoDB connection failed:", e)

    """
    CREATE
    --------------------------------------------------------
    Inserts a single document into the collection.

    Returns:
        True  -> if insert was successful
        False -> if an error occurred
    """

    def create(self, data):

        try:
            result = self.collection.insert_one(data)

            # Return acknowledgement status
            return result.acknowledged

        except Exception as e:
            print("Create error:", e)
            return False

    """
    READ
    --------------------------------------------------------
    Retrieves documents from the collection that match
    the provided query.

    Returns:
        List of matching documents
        Empty list if an error occurs
    """

    def read(self, query):

        try:
            return list(self.collection.find(query))

        except Exception as e:
            print("Read error:", e)
            return []

    """
    UPDATE
    --------------------------------------------------------
    Updates multiple documents that match the query.

    Parameters:
        query       -> documents to match
        new_values  -> values to update

    Returns:
        Number of documents modified
    """

    def update(self, query, new_values):

        try:
            result = self.collection.update_many(
                query,
                {"$set": new_values}
            )

            return result.modified_count

        except Exception as e:
            print("Update error:", e)
            return 0

    """
    DELETE
    --------------------------------------------------------
    Deletes documents that match the query.

    Returns:
        Number of documents deleted
    """

    def delete(self, query):

        try:
            result = self.collection.delete_many(query)

            return result.deleted_count

        except Exception as e:
            print("Delete error:", e)
            return 0