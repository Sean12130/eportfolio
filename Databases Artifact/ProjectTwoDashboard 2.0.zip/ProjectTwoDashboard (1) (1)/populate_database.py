from Python_module_4 import AnimalShelter
import random


"""
Animal population database
--------------------------------------------------------
Creates a large sample dataset of animal records and
inserts them into the MongoDB Animal Shelter database.

Used for testing dashboard functionality including:
- DataTable filtering
- Graph generation
- Map visualization
"""

"""
Database Connection
--------------------------------------------------------
Uses the administrator account to allow full database
access for inserting test data.
"""

db = AnimalShelter(
    username="aacuser",
    password="abc1234",
    host="localhost",
    port=27017,
    db_name="AAC"
)

"""
Breed List
--------------------------------------------------------
Defines all possible dog breeds that can be randomly
assigned to generated animals.
"""

breeds = [
    "Labrador", "German Shepherd", "Golden Retriever", "Beagle",
    "Poodle", "Bulldog", "Husky", "Boxer", "Dachshund", "Rottweiler",
    "Chihuahua", "Great Dane", "Border Collie", "Shih Tzu", "Doberman",
    "Pit Bull", "Australian Shepherd", "Corgi", "Pomeranian", "Mastiff"
]


"""
Name List
--------------------------------------------------------
Defines possible animal names used during data generation.
"""

names = [
    "Max", "Bella", "Charlie", "Luna", "Rocky", "Lucy", "Buddy", "Daisy",
    "Milo", "Sadie", "Cooper", "Bailey", "Bear", "Lola", "Duke",
    "Maggie", "Tucker", "Sophie", "Zeus", "Chloe",
    "Oliver", "Ruby", "Jack", "Zoey", "Toby",
    "Nala", "Jax", "Rosie", "Leo", "Molly",
    "Finn", "Lily", "Sam", "Ellie", "Buster",
    "Harley", "Penny", "Oscar", "Winnie", "Scout",
    "Rex", "Nova", "Apollo", "Hazel", "Bruno",
    "Maple", "Shadow", "Storm", "Willow", "Simba"
]


"""
create_animal Function
--------------------------------------------------------
Generates a single random animal record.

Parameters:
    i -> iteration number (not required but useful
         for tracking or debugging)

Returns:
    Dictionary representing an animal document.
"""


def create_animal(i):

    return {

        # Random animal name
        "name": random.choice(names),

        # Random breed
        "breed": random.choice(breeds),

        # Random age in weeks
        "age_upon_outcome_in_weeks":
            random.randint(10, 300),

        # Random sex
        "sex_upon_outcome":
            random.choice(
                ["Intact Male", "Intact Female"]
            ),

        # Random geographic coordinates
        "location_lat":
            round(random.uniform(30.2, 30.8), 5),

        "location_long":
            round(random.uniform(-97.9, -97.3), 5)
    }

"""
Data Insertion Loop
--------------------------------------------------------
Creates and inserts a specified number of animal
records into the database.
"""

count = 500

for i in range(count):

    animal = create_animal(i)

    db.create(animal)


"""
Completion Message
--------------------------------------------------------
Confirms that the dataset generation process finished.
"""unt):
    animal = create_animal(i)
    db.create(animal)

print(f"{count} animals inserted successfully into AAC database.")