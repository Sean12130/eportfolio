
from pymongo import MongoClient
from pymongo.errors import PyMongoError

class AnimalShelter:
    #CRUD operations for the Animal collection in MongoDB.

    def __init__(self, username, password, host, port, db_name):
        self.username = username
        self.password = password
        self.host = host
        self.port = port
        self.db_name = db_name
        self.collection_name = 'animals'  # Hardcoded collection name

        # Connect to MongoDB
        self.client = MongoClient(f'mongodb://{self.username}:{self.password}@{self.host}:{self.port}/?authSource=admin')
        self.database = self.client[self.db_name]
        self.collection = self.database[self.collection_name]


    # Create method to implement the C in CRUD
    def create(self, data):
        # inserts a document into the collection.
        try:
            result = self.collection.insert_one(data)
            return True if result.inserted_id else False
        except Exception as e:
            print("An error occurred:", e)
            return False
    
    # Read method to implement the R in CRUD with pagination and limit
    def read(self, query):
        # Reads documents based on search.
        try:
            cursor = self.collection.find(query)
            return list(cursor)
        except Exception as e:
            print("An error occurred:", e)
            return []
        
    # Update method to implement the U in CRUD
    def update(self, query, new_values):
        # Updates document.
        try:
            result = self.collection.update_many(query, {'$set': new_values})
            return result.modified_count
        except Exception as e:
            print("An error occurred:", e)
            return 0

    # Delete method to implement the D in CRUD
    def delete(self, query):
        # Deletes documents.
        try:
            result = self.collection.delete_many(query)
            return result.deleted_count
        except Exception as e:
            print("An error occurred:", e)
            return 0
